/** This Package houses all the models.
 * @author Justin Traymond Miles
 * Student ID - 006121780
 */
package Model;