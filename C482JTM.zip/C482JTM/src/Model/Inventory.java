package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/** This is the Inventory class.
 * @author Justin Traymond Miles
 * Student ID - 006121780
 */
public class Inventory {
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    public static ObservableList<Part> getAllParts(){
        return allParts;
    }
    public static ObservableList<Product> getAllProducts(){
        return allProducts;
    }
    private static int partIdTick = 0000;
    private static int prodIdTick = 1000;
    //Adds Part
    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }
    //Adds Product
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }
    //Lookup Part
    public static Part lookupPart(int partId) {
        Part partSolo = null;
        for (Part part : allParts) {
            if (part.getId() == partId) {
                partSolo = part;
            }
        }
        return partSolo;
    }
    //Lookup Product
    public static Product lookupProduct(int productId) {
        Product productSolo = null;

        for (Product product : allProducts) {
            if (product.getId() == productId) {
                productSolo = product;
            }
        }
        return productSolo;
    }
    //Part Update
    public static void updatePart (int index, Part selectedPart) {
        allParts.set(index, selectedPart);
    }
    //Product Update
    public static void updateProduct (int index, Product selectedProduct) {
        allProducts.set(index, selectedProduct);
    }
    //Part Deletion
    public static boolean deletePart(Part selectedPart) {
        if (allParts.contains(selectedPart)) {
            allParts.remove(selectedPart);
            return true;
        }
        else {
            return false;
        }
    }
    //Product Deletion
    public static boolean deleteProduct(Product selectedProduct) {
        if (allProducts.contains(selectedProduct)) {
            allProducts.remove(selectedProduct);
            return true;
        }
        else {
            return false;
        }
    }
    //Searches Parts
    public static ObservableList<Part> lookupPart(String partName) {
        ObservableList<Part> partFiesta = FXCollections.observableArrayList();
        for (Part part : allParts) {
            if (part.getName().equals(partName)) {
                partFiesta.add(part);
            }
        }
        return partFiesta;
    }
    //Searches Products
    public static ObservableList<Product> lookupProduct(String productName) {
        ObservableList<Product> productFiesta = FXCollections.observableArrayList();

        for (Product product : allProducts) {
            if (product.getName().equals(productName)) {
                productFiesta.add(product);
            }
        }
        return productFiesta;
    }
    public static int incPartIdTick() {
        //Example of runtime error correction. Each new part failed to generate new part id
        return ++partIdTick;
    }
    public static int incProdIdTick() {
        //Example of runtime error correction. Each new product failed to generate new product id
        return ++prodIdTick;
    }
    //Adds Sample Data
    static {
        addSampleData();
    }
    public static void addSampleData(){
        //Adds Sample Parts
        int partId = Inventory.incPartIdTick();
        InHouse actifCatlessDownpipes = new InHouse(
                partId,
                "Actif Catless Downpipes",
                249.99,
                12,
                1,
                50,
                2501);
        partId = Inventory.incPartIdTick();
        InHouse actifRaceIntercooler = new InHouse(
                partId,
                "Actif Race Intercooler",
                529.99,
                10,
                1,
                50,
                12501);
        partId = Inventory.incPartIdTick();
        InHouse actifChargePipe = new InHouse(
                partId,
                "Actif Charge Pipe",
                149.99,
                15,
                1,
                50,
                251);
        partId = Inventory.incPartIdTick();
        InHouse actif2PlusFP = new InHouse(
                partId,
                "Actif Bucketed Stg2+ Fuel Pump",
                549.99,
                15,
                1,
                50,
                251);
        partId = Inventory.incPartIdTick();
        Outsourced pittzyBOV = new Outsourced(
                partId,
                "Pittzy Blow-Off Valve",
                150.45,
                7,
                25,
                100,
                "Pittzy");
        Inventory.addPart(actifCatlessDownpipes);
        Inventory.addPart(actifRaceIntercooler);
        Inventory.addPart(actifChargePipe);
        Inventory.addPart(pittzyBOV);
        Inventory.addPart(actif2PlusFP);
        //Add sample products
        int productId = Inventory.incProdIdTick();
        Product actifStage2PlusCombo = new Product(
                productId,
                "Actif Stage 2 + Combo",
                1399.99,
                7,
                1,
                25);
        productId = Inventory.incProdIdTick();
        Product actifStage2Combo = new Product(
                productId,
                "Actif Stage 2 Combo",
                999.99,
                10,
                1,
                25);
        actifStage2PlusCombo.addAssociatedPart(actifCatlessDownpipes);
        actifStage2PlusCombo.addAssociatedPart(actifRaceIntercooler);
        actifStage2PlusCombo.addAssociatedPart(actifChargePipe);
        actifStage2PlusCombo.addAssociatedPart(pittzyBOV);
        actifStage2PlusCombo.addAssociatedPart(actif2PlusFP);
        Inventory.addProduct(actifStage2PlusCombo);
        actifStage2Combo.addAssociatedPart(actifCatlessDownpipes);
        actifStage2Combo.addAssociatedPart(actifRaceIntercooler);
        actifStage2Combo.addAssociatedPart(actifChargePipe);
        actifStage2Combo.addAssociatedPart(pittzyBOV);
        Inventory.addProduct(actifStage2Combo);


    }

}

