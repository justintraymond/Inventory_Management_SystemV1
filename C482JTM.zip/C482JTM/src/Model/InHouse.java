package Model;
/** This is the InHouse part class.
 * @author Justin Traymond Miles
 * Student ID - 006121780
 */
public class InHouse extends Part {
    private int machineId;
    //Constructor
    public InHouse(
            int id,
            String name,
            double price,
            int stock,
            int min,
            int max,
            int machineId) {
        super(
                id,
                name,
                price,
                stock,
                min,
                max);
        this.machineId = machineId;
    }
    //Setter
    /** @param machineId the machineId to set */
    public void setMachineId(int machineId){
        this.machineId = machineId;
    }
    //Getter
    /** @return the machineId. */
    public int getMachineId(){
        return machineId;
    }
}
