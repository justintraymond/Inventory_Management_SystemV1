package Main;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.application.Application;

 /**
 * @author Justin Traymond Miles
 * Student ID - 006121780
 */
/** This class starts the Inventory Management System. FUTURE ENHANCEMENT: Add login screen. RUNTIME ERROR LOCATION: addProductFormCOntroller */
public class Main extends Application {
    @Override
    /**This method Launches Main Form. Javadoc location in root folder. */
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/View/Main Form.fxml"));
        Scene scene = new Scene(root);
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        //Sample Parts

        launch(args);
    }
}


