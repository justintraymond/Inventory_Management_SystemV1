/** This Package houses the main start/application.
 * @author Justin Traymond Miles
 * Student ID - 006121780
 */
package Main;