/**
  RUNTIME ERROR: Example of runtime error correction. Search button wasn't parsing items with matching criteria into table.
  fixed by adding this to addProductFormController search function
  " addProducts.setItems(partFiesta);
             if (partFiesta.size() == 0) {
                     whoaAlert(1);"
 */